import java.util.EmptyStackException;

/**
 * Complete the empty methods so that this class works with the StackDriver.java
 * class given. You may implement using either a LinkedList or an array. You MAY
 * NOT use the Java library Stack, LinkedList, or ArrayList classes.
 * 
 * @author Monsol Cole-Kweli
 *
 */
public class GenericStack<T> implements StackInterface<T> {

	private Node head;
	private int size;
	private EmptyStackException ese;

	GenericStack() {
		head = null;
		size = 0;
	}

	/**
	 * Adds a new entry to the top of this stack.
	 * 
	 * @param newEntry An object to be added to the stack.
	 */
	@Override
	public void push(T newEntry) {
		// TODO Auto-generated method stub
		Node newNode = new Node(newEntry);
		if (isEmpty()) {
			head = newNode;
		} else {
			newNode.next = head;
			head = newNode;
		}
		size++;
	}

	/**
	 * Retrieves this stack's top entry.
	 * 
	 * @return The object at the top of the stack.
	 * @throws EmptyStackException if the stack is empty.
	 */
	@Override
	public T pop() {
		// TODO Auto-generated method stub
		if (isEmpty()) {
			throw ese;
		}
		
		T dataNoMore = head.data;

		// To remove first element, set head = next element in list and reduce size
		head = head.next;
		if (isEmpty()) {
			head = null;
		}

		size--;
		return dataNoMore;
	}

	/**
	 * Retrieves this stack's top entry.
	 * 
	 * @return The object at the top of the stack.
	 * @throws EmptyStackException if the stack is empty.
	 */
	@Override
	public T peek() {
		// TODO Auto-generated method stub
		if (isEmpty()) {
			throw ese;
		}
		
		return head.data;
	}

	/**
	 * Detects whether this stack is empty.
	 * 
	 * @return True if the stack is empty.
	 */
	@Override
	public boolean isEmpty() {
		// TODO check if stack is empty
		return size == 0;
	}

	/** Removes all entries from this stack. */
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		while (!isEmpty()) {
			pop();
		}
	}

	// A private Node class. By making it an inner class,
	// the outer class can access it easily, but the client cannot.
	private class Node {
		private T data;
		private Node next;

		// Constructs a new node with the specified data
		private Node(T data) {
			this.data = data;
			this.next = null;
		}
	}

}
