
public class UniqueID {
	String first;
	String last;
	String key = first + " " + last;
	UniqueID() {
		// do nothing - all variables equal null until set methods called.
	}

	UniqueID(String key) {
		this.key = key;
		
	}
	public void setfirst(String first){
		this.first = first;
	}
	public void setlast(String last){
		this.last = last;
	}

	public String toString() {

		return key;
	}

}
