import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

/**
 * Class: AddressMapping
 * 
 * @author Monsol Cole-Kweli
 * @version 1.1 
 * Course : CSE 274 Fall 2023
 * Written: Nov 5, 2023
 *
 * This class: Main Driving class for programming project 4
 * Purpose: - Read in information. Save info into HashMap, 
 * search HashMap, and print information. 
 */
public class AddressMapping {
	/**
	 * This method reads in info from file and 
	 * saves into HashMap
	 * @param file the file to read from
	 * @param adLines the HashMap to save to
	 * @return adLines
	 */
	private static HashMap<String, Address> read(String file, HashMap<String, Address> adLines) {
		try {
			File adFile = new File(file);
			Scanner adScan = new Scanner(adFile);

			while (adScan.hasNextLine()) {
				Address temp = new Address();
				String nameFirst = adScan.nextLine();
				String nameLast = adScan.nextLine();
				String address = adScan.nextLine();
				String zip = adScan.nextLine();
				String phone = adScan.nextLine();

				int code = Integer.parseInt(zip);

				temp.setFirstName(nameFirst);
				temp.setLastName(nameLast);
				temp.setStreetAddress(address);
				temp.setPhoneNumber(phone);
				temp.setZipcode(code);

				String key = nameFirst + " " + nameLast;
				adLines.put(key, temp);
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println("\n:: File Not Found ::\n");
		}
		return adLines;
	}

	/**
	 * This method searches the HashMap and prints the value
	 * @param option the user option to search in map
	 * @param adLines the HashMap to search
	 */
	private static void searchMap(String option, HashMap<String, Address> adLines) {
		if (adLines.containsKey(option)) {
			System.out.println("\n" + adLines.get(option));
		} else {
			System.out.println("\n:: Entry Not Found ::");
		}
	}

	/**
	 * This method is the user interface and prompts the user
	 * to input file name and option to search map
	 * @param adLines the HashMap to read and search
	 */
	private static void userInterface(HashMap<String, Address> adLines) {

		Scanner kb = new Scanner(System.in);
		String file;
		boolean empty = true;

		do {
			System.out.println("Please input file name of the address list (or input -1 to exit): ");
			file = kb.nextLine();

			if (!file.equals("-1")) {
				adLines = read(file, adLines);
				if (!adLines.isEmpty()) {
					empty = false;
				}
			}

		} while (empty && !file.equals("-1"));

		String option = "";
		do {
			if (!file.equals("-1")) {
				System.out.println("\nWho would you like to search for " + "(or enter -1 to exit program)?");
				option = kb.nextLine();
				if(option.equals("-1")) {
					return;
				}
				searchMap(option, adLines);
			} else {
				option = "-1";
			}
		} while (!option.equals("-1"));

		
	}

	/**
	 * This is the Main driving method 
	 * @param args
	 */
	public static void main(String[] args) {
		HashMap<String, Address> adLines = new HashMap<>();
		userInterface(adLines);
		System.out.println("\nGood bye.");
	}
}