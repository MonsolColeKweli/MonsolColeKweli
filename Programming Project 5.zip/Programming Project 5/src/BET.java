import java.util.Stack;

/**
 * Class: BET (Binary Expansion Tree)
 * 
 * @author Monsol Cole-Kweli
 * @version 1.1
 * Course : CSE 274 Fall 2023
 * Written: Nov 29, 2023
 * 
 * This Class: This is a binary expression tree. It is initialized with a postfix string and
 * can be printed out as either the postfix expression or the infix expression.
 * Purpose: It is meant to read in a postfix string and print it in infix notation.
 */
public class BET {

	private BinaryNode root;
	private String postfix;

	/**
	 * Default constructor - creates an empty tree
	 */
	public BET() {
		// creates an empty Tree
		root = null;
	}

	/**
	 * Constructor accepting postfix string to parse
	 * 
	 * @param pf - the postfix string
	 */
	public BET(String pf) {
		// builds tree based on input postfix string
		buildFromPostfix(pf);
	}

	/**
	 * Method accepts input string and builds the tree based on it
	 * 
	 * @param pf - the postfix string
	 * @return - true if tree build, false if bad pf format
	 */
	public boolean buildFromPostfix(String pf) {
		// Clear existing tree
		root = null;

		// Tokenize the postfix expression
		/*
		 * Use 'StringObjecct'.split to section elements into array.
		 * '\\': Escapes the backslash special character
		 * 's': Represents the whitespace character class. 
		 * '+': Denotes one or more of the preceding whitespace character.
		 */
		String[] tokens = pf.split("\\s+");

		// Stack to track nodes
		Stack<BinaryNode> tokenStack = new Stack<BinaryNode>();

		for (String token : tokens) {
			if (isOperator(token)) {
				// Operator encountered, pop two operands, create a new node, and push it back
				if (tokenStack.size() < 2) {
					throw new IllegalArgumentException("Invalid postfix expression");
				}
				BinaryNode operationNode = new BinaryNode(token);
				operationNode.right = tokenStack.pop();
				operationNode.left = tokenStack.pop();
				tokenStack.push(operationNode);
			} else {
				// Operand encountered, push it onto the stack
				tokenStack.push(new BinaryNode(token));
			}
		}

		// The final result should be the root of the tree
		if (tokenStack.size() != 1) {
			throw new IllegalArgumentException("Invalid postfix expression");
		}
		root = tokenStack.pop();

		return true;
	}

	/**
	 * This method reads in a string token and checks to see if it belongs to a math
	 * operator.
	 * 
	 * @param token the token to check
	 * @return true if the token is an operator, false otherwise
	 */
	private boolean isOperator(String token) {
		// TODO Auto-generated method stub
		return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/");
	}

	/**
	 * Method that prints an infix expression from the BET. If tree is empty, prints
	 * "No expression available"
	 */
	public void printInfixExpression() {
		if (isEmpty()) {
			System.out.println("No expression available");
		} else {
			printInfixExpression(root);
			System.out.println(); // Move to the next line after printing
		}
	}

	/**
	 * * This a recursive helper method for printInfixExpression()
	 * 
	 * @param node the node to print
	 */
	private void printInfixExpression(BinaryNode node) {
		if (node != null) {
			if (isOperator(node.element)) {
				System.out.print("( ");
			}
			printInfixExpression(node.left);
			System.out.print(node.element + " ");
			printInfixExpression(node.right);
			if (isOperator(node.element)) {
				System.out.print(") ");
			}
		}
	}

	/**
	 * Method that prints postfix expression used to build BET. If tree is empty,
	 * prints "No expression available"
	 */
	public void printPostfixExpression() {
		if (isEmpty()) {
			System.out.println("No expression available");
		} else {
			printPostfixExpression(root);
			System.out.println(); // Move to the next line after printing
		}
	}

	/**
	 * This a recursive helper method for printPostfixExpression()
	 * 
	 * @param node the node to print
	 */
	private void printPostfixExpression(BinaryNode node) {
		if (node != null) {
			printPostfixExpression(node.left);
			printPostfixExpression(node.right);
			System.out.print(node.element + " ");
		}
	}

	/**
	 * Outputs number of nodes in the tree Helping caller method of recursive size.
	 * 
	 * @return int
	 */
	public int size() {
		return size(root);
	}

	/**
	 * Outputs number of nodes in the tree
	 * 
	 * @param node
	 * @return
	 */
	private int size(BinaryNode node) {
		if (node == null) {
			return 0;
		} else {
			return 1 + size(node.left) + size(node.right);
		}
	}

	/**
	 * isEmpty() - returns true if empty, false if not
	 * 
	 * @return boolean
	 */
	public boolean isEmpty() {
		return root == null;
	}

	/**
	 * BinaryNode class- class representing a node in the BET. Not accessible
	 * outside this class
	 * 
	 * @author john1819
	 *
	 */
	private class BinaryNode {
		String element;
		BinaryNode right;
		BinaryNode left;

		/**
		 * Constructor to create node with known data
		 * 
		 * @param String - data to be stored
		 */
		public BinaryNode(String element) {
			this.element = element;
			right = null;
			left = null;
		}

	}

}
