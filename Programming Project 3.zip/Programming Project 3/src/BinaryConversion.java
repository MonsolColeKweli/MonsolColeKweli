import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Stack;

/**
 * Class: BinaryConversion
 * 
 * @author Monsol cole-Kweli
 * @version 1.1 
 * Course : CSE 274 Fall 2023
 * Written: Oct 20, 2023
 *
 * This class: BinaryConversion class for programming project 3
 * Purpose: - Convert any given positive integer into 
 * its binary counterpart. 
 */
public class BinaryConversion {
	
	/**
	 * This method takes in an integer and converts
	 * it to its binary counterpart
	 * @param input
	 * @return biValue the binary code to return
	 */
	private static String conversion(int input) {
		Stack<Integer> biStack = new Stack<Integer>();
		String biValue = "";
		
		if(input == 0) {
			return "0";
		}
		while( input > 0) {
			int division = input % 2;
			biStack.push(division);
			input /= 2;
		}
		
		while(!biStack.isEmpty()) {
			biValue += biStack.pop();
		}
		return biValue;
	} //End conversion()
		
	/**
	 * Main driving method for BinaryConversion
	 * Contain do-while loop to continue program UI.
	 * @param args
	 */
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		int input = 0;
		
		System.out.println("Welcome to the Binary Conversion Program.\n"
				+ "Here you can input any positive integer >= 0\n"
				+ "and it will convert to its Binary Counterpart.\n");
		
		//Driving loop to continue program
		do {
			try {
				Scanner kb = new Scanner(System.in);
			
				System.out.println("Please enter a positive number (or -1 to exit): ");
				input = kb.nextInt();
				
				//End Program Check
				if(input < 0) {
					 System.out.println("\nThanks for using the program,\n"
					 		+ "Good bye.");
				} else {
					System.out.println("\nBinary equivalent is " + conversion(input));
				}
			
			}catch(InputMismatchException ime) {
				System.out.println("\nPlease only use Integer Inputs");
			}
			
		}while(input >= 0);
	} // End main()
} // End BinarayConversion
