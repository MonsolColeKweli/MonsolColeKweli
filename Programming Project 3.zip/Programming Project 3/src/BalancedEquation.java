import java.util.Scanner;
import java.util.Stack;

/**
 * Class: BalancedEquation
 * 
 * @author Monsol cole-Kweli
 * @version 1.1 
 * Course : CSE 274 Fall 2023
 * Written: Oct 20, 2023
 *
 * This class: Main class for programming project 3
 * Purpose: - Determine whether or not an equation is valid
 * based soley on if the parenthesis are balanced. 
 */
public class BalancedEquation {
	
	/**
	 * This method checks the validity if the 
	 * parenthesis in the equations
	 * @param input the string equation to check
	 * @return 
	 */
	private static boolean validityCheck(String input) {
		Stack<Character> validStack = new Stack<Character>();
		boolean validity = true;
		
		for (char character : input.toCharArray()) {
            if (character == '(') {
                validStack.push(character);
                
            } else if (character == ')') {
                if (validStack.isEmpty() || validStack.pop() != '(') {
                    validity = false; // Unbalanced closing parenthesis
                }
            } // end else-if
        } // end for
		return validity && validStack.isEmpty();
	} // End validityCheck()
	
	/**
	 * Main driving method for BalancedEquation class.
	 * Contain do-while loop to continue program UI.
	 * @param args
	 */
	public static void main(String[] args) {
		String input = "";
		
		System.out.println("Welcome to the Equation Validity Program.\n"
				+ "Here you can input any any equation utilizing parenthesis >= 0\n"
				+ "and it will determine the validity of the equation.\n");
		
		//Driving loop to continue program
		do {
			Scanner kb = new Scanner(System.in);
		
			System.out.println("Please enter an equation (or enter nothing to end): ");
			input = kb.nextLine();
			
			//End Program Check
			if(input.isEmpty()) {
				 System.out.println("\nThanks for using the program,\n"
				 		+ "Good bye.");
			}
			
			if(validityCheck(input)){
				System.out.println("\nThis equation is valid!");
			} else if(!validityCheck(input)){
				System.out.println("\nThis equation is NOT valid :(");
			}
		
		}while(!input.isEmpty()); // End do-while
	} // End main()

}
